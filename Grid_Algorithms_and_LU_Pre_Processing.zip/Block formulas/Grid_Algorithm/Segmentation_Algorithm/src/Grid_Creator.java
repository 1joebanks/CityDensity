import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Grid_Creator {

	public static void main (String[] args){
		int R = 6371, roundedUpWidth, roundedUpHeight; //these are in Km and uses spherical geometry
		double maxLat = 0, minLat = 0, maxLong = 0, minLong = 0, bearing12, bearing13, widthA, widthB, heightA, heightB, newLat, newLong;
		double[] point1 = new double [2], point2 = new double [2], point3 = new double [2], point4 = new double [2];
		double [] [] latitudeArray, longitudeArray;
		String cityName;
		double squareSize; //resolution squared. i.e. 0.5 = 500m x 500m cell size

		//array pointx[0] is lat,,, pointx[1] is long,,,

		Scanner input = new Scanner(System.in);

		System.out.println("This program will create a grid of squares in GEOJSON format based on maximum and minimum longitude and latitude of a given area.");
		System.out.println("For this program to output the grid in 4-point-polygons, it requires the maxmimum latitude, minimum latitude, maximum longitude, "
							+ "minimum longitude and the resolution of the square.");
		
		System.out.println("Please enter the name of the city:");
		cityName = input.nextLine().replace(" ", "_");
		
		System.out.println("Please enter the resolution of each square in km (i.e. 0.5 for 500mx500m)");
		squareSize = input.nextDouble();
		
		System.out.println("Please enter the Maximum latitude");
		maxLat = input.nextDouble();

		System.out.println("Please enter the Minimum latitude");
		minLat = input.nextDouble();

		System.out.println("Please enter the Maximum longitude");
		maxLong = input.nextDouble();

		System.out.println("Please enter the Minimum longitude");
		minLong = input.nextDouble();


		point1[0] = maxLat; 
		point1[1] = minLong;

		point2[0] = maxLat; 
		point2[1] = maxLong;

		point3[0] = minLat; 
		point3[1] = minLong;

		point4[0] = minLat; 
		point4[1] = maxLong;

		//for point 1-2
		widthA = length(point1, point2, R);
		widthB = length(point3, point4, R);
		heightA = length(point1, point3, R);
		heightB = length(point2, point4, R);

		roundedUpWidth = (int) Math.ceil(Math.max(widthA, widthB)); //need to ensure ceil returns correct rounded result
		roundedUpHeight = (int) Math.ceil(Math.max(heightA, heightB));

		//if not even, then make even
		roundedUpWidth=evenChecker(roundedUpWidth);
		roundedUpHeight=evenChecker(roundedUpHeight);
		int tempWidth = (int) (roundedUpWidth/squareSize);
		int tempHeight = (int) (roundedUpHeight/squareSize);
		//array is in format - array[rows][columns] or... --array[y][x]
		latitudeArray = new double [tempWidth][tempHeight]; //define new size for array for using two different arrays
		longitudeArray = new double [tempWidth][tempHeight];

		//bearing 1 to 2
		bearing12 = bearing(point1, point2); //should be equal to 0 

		//bearing 1 to 3
		bearing13 = bearing(point1, point3); //should be equal to 180

		
		//initialise
		latitudeArray[0][0] =  point1[0];
		longitudeArray[0][0] = point1[1];
		double []tempPoint = new double [2];
		
		//create top row
		for (int i=1; i<tempWidth;i++){

			tempPoint[0] = latitudeArray[i-1][0];
			tempPoint[1] = longitudeArray[i-1][0];

			newLat = NewLat(latitudeArray[i-1][0], bearing12, squareSize, R);
			newLong = NewLong(tempPoint, bearing12, squareSize, newLat, R);
			latitudeArray [i][0] = Math.toDegrees(newLat);
			longitudeArray [i][0] = Math.toDegrees(newLong);
		}


		for (int i=0; i<tempWidth;i++){
			for (int j=1; j<tempHeight;j++){
				tempPoint[0] = latitudeArray[i][j-1];
				tempPoint[1] = longitudeArray[i][j-1];
				latitudeArray[i][j] = Math.toDegrees(NewLat(latitudeArray[i][j-1], bearing13, squareSize, R));
				longitudeArray[i][j] = Math.toDegrees(NewLong(tempPoint, bearing13, squareSize, latitudeArray[i][j], R));
			}
		}	

		//print to geojson file in route directory
		File file = new File(cityName + "_Grid_Coordinates.geojson");
		try {
			file.createNewFile();

			BufferedWriter br = new BufferedWriter(new FileWriter(file));
			StringBuilder sb = new StringBuilder();
			//longitude first latitude second

			int x = 0;
			sb.append("{ \"type\": \"FeatureCollection\",");
			br.write(sb.toString());
			br.newLine();

			sb.setLength(0);
			sb.append("  \"features\": [");
			br.write(sb.toString());
			br.newLine();
			br.newLine();

			for(int j = 0;j<tempHeight-1;j++){
				for(int i = 0; i<tempWidth-1;i++){
					sb.setLength(0);
					sb.append("    { \"type\": \"Feature\",");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("      \"geometry\": {");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("        \"type\": \"Polygon\",");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("        \"coordinates\": [");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("          [ [" + longitudeArray[i][j] + "," + latitudeArray[i][j] + "],");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("            [" + longitudeArray[i+1][j] + "," + latitudeArray[i+1][j] + "],");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("            [" + longitudeArray[i+1][j+1] + "," + latitudeArray[i+1][j+1] + "],");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("            [" + longitudeArray[i][j+1] + "," + latitudeArray[i][j+1] + "] ]");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("        ]");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("      },");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("      \"properties\": {");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("        \"prop0\": \"" + x + "\"}");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					if((j==tempHeight-2) & (i==tempWidth-2)) {
						sb.append("    }");	
					}
					else{
					sb.append("    },");
					}
					br.write(sb.toString());
					br.newLine();
					br.newLine();
					x=x+1;
				}
			}

			sb.setLength(0);
			sb.append("  ]");
			br.write(sb.toString());
			br.newLine();

			sb.setLength(0);
			sb.append("}");
			br.write(sb.toString());
			br.newLine();

			br.close();


		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("Done! File '" + cityName + "_Grid_Coordinates.geojson' saved in project source directory.");
	}




	public static int evenChecker (int input){
		// if odd
		if (input % 2 != 0) {
			input = input +1;
		} 
		return input;
	}

	public static double NewLat(double point1Lat, double bearing, double roundedLength, double R) {
		double newLat = 0;

		newLat = Math.asin((Math.sin(Math.toRadians(point1Lat))*Math.cos((double)roundedLength/R)) + (Math.cos(Math.toRadians(point1Lat))*Math.sin((double)roundedLength/R)*Math.cos(bearing)));

		return newLat;


	}

	public static double NewLong(double pointx[], double bearing, double roundedLength, double newLat, double R) {
		double newLong = 0;
		double temp = (double)roundedLength/R;

		newLong = ((Math.toRadians(pointx[1])) + (Math.atan2(Math.sin(bearing)*Math.sin(temp)*Math.cos(Math.toRadians(pointx[0])), 
				Math.cos(temp)-Math.sin(Math.toRadians(pointx[0]))*Math.sin(newLat))));

		newLong = ((newLong+3*Math.PI) % (2*Math.PI)) - Math.PI;
		return newLong;
	}

	public static double bearing(double[] pointx, double[] pointy){
		double y = Math.sin(Math.toRadians(pointy[1] - pointx[1])) * Math.cos(Math.toRadians(pointy[0]));
		double x = Math.cos(Math.toRadians(pointx[0]))*Math.sin(Math.toRadians(pointy[0])) -
				Math.sin(Math.toRadians(pointx[0]))*Math.cos(Math.toRadians(pointy[0]))*Math.cos(Math.toRadians(pointy[1] - pointx[1]));

		return (Math.atan2(y, x));
	}

	public static double length(double[] pointx, double[] pointy, int R){
		double deltaLong;
		double Length;
		double sigma;

		deltaLong = ((Math.toRadians(pointx[1])) - (Math.toRadians(pointy[1])));
		sigma = Math.acos(((Math.sin(Math.toRadians(pointx[0])))*(Math.sin(Math.toRadians(pointy[0]))))+
				((Math.cos(Math.toRadians(pointx[0])))*(Math.cos(Math.toRadians(pointy[0])))*(Math.cos(deltaLong))));
		Length = R*sigma;
		return Length;
	}
}
