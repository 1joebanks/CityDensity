import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;


public class TubeData_Preprocessing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String columnHeaders = null;
		int TubeDataInput[][] = null ;
		int TubeDataOutput[][]=null;
		String TubeDataFN;
		Scanner input = new Scanner(System.in);
		int fileHeight = 0;

		System.out.println("Please enter the name of the London Underground data set CSV file (without the csv extension): ");
		TubeDataFN = input.nextLine();

		String[] cols;
		String[] dateCols = null;
		File file = new File (TubeDataFN + ".csv");
		FileReader var;


		try {
			var = new FileReader(file);

			BufferedReader br = new BufferedReader(var);
			String lineRead = null;

			LineNumberReader reader = null;//chagned mind, just get first 2 columns
			reader = new LineNumberReader(new FileReader(file));

			try {
				while ((reader.readLine()) != null);

				fileHeight= reader.getLineNumber();

				lineRead = br.readLine();
				columnHeaders = lineRead;
				cols = lineRead.split(",");
				columnHeaders="";
				for(int i=0;i<cols.length;i++){
					if(i!=1){
						columnHeaders = columnHeaders.concat(cols[i] + ", ");
					}
				}
				TubeDataInput = new int [5][fileHeight-1];//-1 remove header
				TubeDataInput = csvToArray(TubeDataInput,  reader,  fileHeight, cols,  br, dateCols);
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int tempNLC=0;
		List<Integer> Dates = new ArrayList<Integer>();
		List<Integer> Stations = new ArrayList<Integer>();
		List<Integer> Times = new ArrayList<Integer>();
		for(int i=0;i<TubeDataInput[0].length;i++){
			if(!Times.contains(TubeDataInput[3][i])){
				Times.add(TubeDataInput[3][i]);
			}

			if(!Stations.contains(TubeDataInput[0][i])){
				Stations.add(TubeDataInput[0][i]);
			}

			if(!Dates.contains(TubeDataInput[1][i])){
				Dates.add(TubeDataInput[1][i]);
			}
		}

		int NumberOfDates = Dates.size();		
		int NumberOfStations = Stations.size();
		int NumberOfTimes = Times.size();

		Collections.sort(Times);
		Collections.sort(Dates);

		ListIterator<Integer> StationsIterator = Stations.listIterator();
		ListIterator<Integer> DatesIterator = Dates.listIterator();
		ListIterator<Integer> TimesIterator = Times.listIterator();

		int newArraySize;
		newArraySize = (NumberOfTimes)*(NumberOfStations)*(NumberOfDates);
		//count how many stations
		TubeDataOutput = new int[5][newArraySize];
		int newPointer=0, tempDate=0,tempDay=0;

		while(StationsIterator.hasNext()){	
			tempNLC= StationsIterator.next();
			DatesIterator = Dates.listIterator(); //restarts iterator
			while(DatesIterator.hasNext()){
				tempDate = DatesIterator.next();
				tempDay = Dates.indexOf(tempDate)+1;
				if(tempDay>7){//due to 14 days for one station max, need to restart weekday of 1
					tempDay = tempDay-7;
				}
				TimesIterator = Times.listIterator(); //restarts iterator
				while(TimesIterator.hasNext()){
					TubeDataOutput[0][newPointer] = tempNLC;
					TubeDataOutput[1][newPointer] = tempDate; //adds the date
					TubeDataOutput[2][newPointer] = tempDay; //need to add the day
					TubeDataOutput[3][newPointer] = TimesIterator.next();
					//					TubeDataOutput[4][newPointer] = 10; // this can be uncommented if want the default to be 10 rather than 0 to match TFL to avoid tracking
					newPointer++;
				}
			}
		}

		int offset=0;
		for(int i=0;i<TubeDataInput[0].length;i++){
			for(int j=offset;j<TubeDataOutput[0].length;j++){
				if((TubeDataOutput[0][j]==TubeDataInput[0][i])&& (TubeDataOutput[1][j]==TubeDataInput[1][i]) && (TubeDataOutput[2][j]==TubeDataInput[2][i])&& (TubeDataOutput[3][j]==TubeDataInput[3][i])){
					TubeDataOutput[4][j]=TubeDataInput[4][i];
					offset=j;
					break;
				}
			}
		}

		File TubeDataOutputFile = new File( TubeDataFN +" Pre-Processed.csv");
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(TubeDataOutputFile));		
			TubeDataOutputFile.createNewFile();

			bw.write(columnHeaders);
			bw.newLine();
			String TempConcat="";
			for(int i=0;i<(TubeDataOutput[0].length);i++){
				for(int j=0;j<5;j++){
					if(j==1){
					}
					TempConcat = TempConcat.concat(String.valueOf(TubeDataOutput[j][i])+", ");
				}
				bw.write(TempConcat);
				TempConcat="";
				bw.newLine();
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Done");
	}

	public static int[][]csvToArray(int[][]TubeDataInput, LineNumberReader reader, int fileHeight, String[] cols, BufferedReader br,String[]dateCols){
		String lineRead;
		for(int j=0; j<fileHeight-1;j++){

			try {
				lineRead = br.readLine();
				cols = lineRead.split(",");	

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for (int i = 0; i<=5;i++){//6 columns
				String DateTemp = cols[i], DateBuild = "", TimeBuild="";

				int output=0;
				if(i==1){//dont want column 1
					//					i++;//offset as don't want column 1. only 0,2,3,4,5
				}
				else if(i==2){
					dateCols = DateTemp.split("/");
					for(int m=0;m<3;m++){
						DateBuild = DateBuild.concat(dateCols[m].toString());
					}
					output = Integer.valueOf(DateBuild);
					TubeDataInput[i-1][j] = output;
				}
				else if(i==3){
					switch(cols[i]){
					case "SUN": TubeDataInput[i-1][j] = 1; break;
					case "MON": TubeDataInput[i-1][j] = 2; break;
					case "TUE": TubeDataInput[i-1][j] = 3; break;
					case "WED": TubeDataInput[i-1][j] = 4; break;
					case "THU": TubeDataInput[i-1][j] = 5; break;
					case "FRI": TubeDataInput[i-1][j] = 6; break;
					case "SAT": TubeDataInput[i-1][j] = 7; break;
					}

				}
				else if(i==4){
					TimeBuild = TimeBuild.concat(cols[i].substring(0, 2));
					String TimeBuild1 = cols[i].substring(3, 5);
					int minutes = Integer.valueOf(TimeBuild1);
					if(minutes==0){
						TimeBuild = TimeBuild.concat(TimeBuild1);
					}else{//will be a 50
						TimeBuild = TimeBuild.concat("50");
					}

					output = Integer.valueOf(TimeBuild);
					TubeDataInput[i-1][j] = output;
					//					System.out.println("TimeBuild");

				}else if(i==5){
					TubeDataInput[i-1][j] = Integer.parseInt(cols[i]);
				}
				else {
					TubeDataInput[i][j] = Integer.parseInt(cols[i]);
				}
			}
		}
		return TubeDataInput;
	}

}



