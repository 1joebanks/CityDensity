import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Scanner;


public class BoroughAssignment {
	public static void main (String[] args){
		String[][] newPOICSV = null;
		String firstLinePOI = null;
		double inputPOI[][] ;
		double [][][]geoJsonArray;
		int longditudeGridWidth = 0;
		int heightGeoJson =0;
		int offset;
		int GeoJasonj =0;
		String[] cols1;
		double[] columns, geoJsonBottomLatVals, firstGeo;
		double GridNoAtStartLat;
		double geoLong, geoLat = 0, GridNo = 0;
		double geoJsonRightSideLatVals = 0;
		boolean find = false, flag1 = false, GridPosFound=false;
		String Geo_FileName, InputPOIFileName;
		Scanner input = new Scanner(System.in);

		System.out.println("This is a program to assign particular points if intereset from given coordinates a grid number generatred from assiciated blocks program.");
		System.out.println("The program needs to have use of two files, the GEOJSON grid coordinates file, and a file of your choice in CSV format, with the first columns assigned longditude and lattitude respecitvely,"
				+ "and any other columns after that will remain in the updated file. In the updated file, there will be an additional column names gridNo with each entry having a number associated to it if it is within the given boundaries.");
		System.out.println("Please first ensure the two files are saved in this JAVA file's root directory");
		
		System.out.println("Please enter the name of the GEOJSON grid co-ordinates:");
		Geo_FileName = input.nextLine();
		
		System.out.println("Please enter the name of the Input Points of Intereset CSV file:");
		InputPOIFileName = input.nextLine();
		
		String[] cols;
		File file = new File (InputPOIFileName + ".csv");
		FileReader var;

		File file2 = new File (InputPOIFileName + ".csv"); //need to read this twice as needs buffered run through twice
		FileReader var2;

		File file1 = new File (Geo_FileName + ".geojson");
		FileReader var1;
		try {
			var = new FileReader(file);
			var2 = new FileReader(file2);

			BufferedReader br = new BufferedReader(var);
			String lineRead = null;
			try {
				
			int heightPOI = 0;
			LineNumberReader reader = null;
			reader = new LineNumberReader(new FileReader(file));
			
			while ((reader.readLine()) != null); //get number of lines of the POI file
			heightPOI= reader.getLineNumber();

			lineRead = br.readLine();
			firstLinePOI = lineRead;
			cols = lineRead.split(",");	

			inputPOI = new double [2][heightPOI];

			for(int j=0; j<heightPOI-1;j++){
				lineRead = br.readLine();
				for (int i = 0; i<2;i++){
					lineRead.startsWith("\"");
					cols = lineRead.split(",");	
					inputPOI[i][j] = Double.parseDouble(cols[i]);
				}
			}
			br.close();


//////////////////////////////for GeoJson file/////////////////////////////////////////////////////////////////////////////////
			
			
			//NOTE MAY NEED TO ENSURE THE CORRECT ROUNDING IS PERFORMED
			
			var1 = new FileReader(file1);	
			BufferedReader br1 = new BufferedReader(var1);

			//////retrieve number of lines of GeoJson file////
			LineNumberReader reader1 = null;
			reader1 = new LineNumberReader(new FileReader(file1));
			while ((reader1.readLine()) != null);
			heightGeoJson = reader1.getLineNumber();
			//////retrieve number of lines of GeoJson file////
			

			///get first line to know true number of columns//
			geoJsonArray = new double [1] [(heightGeoJson)/14] [3];//array within 2d array this is the array for the new file. //14 lines between entries
			double tempLong; //need to minus longskipearly from here then create a new loop that size taking other missing variables //should i take all variables from gojson
			offset=7;

			for (int x=0;x<=offset;x++){ //get to the initial correct line number using offset
				lineRead = br1.readLine();
			}
			//initial offset.
			cols1 = (lineRead.substring(13, lineRead.lastIndexOf(",")-2)).split(","); //cols[0] is longditude

			for(GeoJasonj=0;GeoJasonj<(heightGeoJson/14)-longditudeGridWidth;GeoJasonj++){
				offset = 7;
				columns = new double[]{Double.parseDouble(cols1[0]), Double.parseDouble(cols1[1])};//creates new array for holding new temp values
				geoJsonArray[0][GeoJasonj][0]= columns[0]; //so it would be to query [i][j] for long[0]
				geoJsonArray[0][GeoJasonj][1]= columns[1]; //so it would be to query [i][j] for lat[1]
				tempLong = Math.round((geoJsonArray[0][GeoJasonj][0])*1000000000000d)/1000000000000d;	

				if( Math.round((geoJsonArray[0][0][0])*1000000000000d)/1000000000000d == tempLong & longditudeGridWidth==0 ){	//width		
					longditudeGridWidth = GeoJasonj;
				}
				//THIS NEEDDS TO BE HERE TO GET END RIGHT CO-ORDINATES
				if(longditudeGridWidth != 0){
					if(GeoJasonj == (longditudeGridWidth*2)-1){
						lineRead = br1.readLine();
						cols1 = (lineRead.substring(13, lineRead.lastIndexOf(",")-2)).split(",");
						columns = new double[] {Double.parseDouble(cols1[0]), Double.parseDouble(cols1[1])};//creates new array for holding new temp values
						geoJsonRightSideLatVals= columns[0]; //assign longditude value of the next line
						offset = offset-1;
					}
				}
				for (int x=0;x<offset;x++){ //get to the initial correct line number using offset
					lineRead = br1.readLine();
				}
				
			
				geoJsonArray[0][GeoJasonj][2]= Double.parseDouble(lineRead.substring(19, lineRead.lastIndexOf("\""))); //so it would be to query [i][j] boxNumber
				 //get to next position before the loop. 
				offset = 7;
				for (int x=0;x<offset;x++){ //get to the initial correct line number using offset
					lineRead = br1.readLine();
				}
				cols1 = (lineRead.substring(13, lineRead.lastIndexOf(",")-2)).split(",");
			}
			
			geoJsonBottomLatVals = new double[longditudeGridWidth];
			for(int b = 0; b<longditudeGridWidth;b++){ 
				cols1 = (lineRead.substring(13, lineRead.lastIndexOf(",")-2)).split(",");
				///now to do last line
				columns = new double[] {Double.parseDouble(cols1[0]), Double.parseDouble(cols1[1])};//creates new array for holding new temp values
				geoJsonArray[0][GeoJasonj+b][0]= columns[0]; //so it would be to query [i][j] for long[0]
				geoJsonArray[0][GeoJasonj+b][1]= columns[1]; //so it would be to query [i][j] for lat[1]

				lineRead = br1.readLine();
				lineRead = br1.readLine();
				cols1 = (lineRead.substring(13, lineRead.lastIndexOf(",")-2)).split(",");
				columns = new double[] {Double.parseDouble(cols1[0]), Double.parseDouble(cols1[1])};//creates new array for holding new temp values
				geoJsonBottomLatVals[b]= columns[1]; //assign lattitude value of the next line

				offset=5;
				for (int x=0;x<offset;x++){ //get to the initial correct line number using offset
					lineRead = br1.readLine();
				}

				geoJsonArray[0][GeoJasonj+b][2]= Double.parseDouble(lineRead.substring(19, lineRead.lastIndexOf("\""))); //so it would be to query [i][j] boxNumber
				offset = 7; //get to next position before the loop. 
				for (int x=0;x<offset;x++){ //get to the initial correct line number using offset
					lineRead = br1.readLine();
				}
			}			

			br1.close();

//////////////////////////////for GeoJson file end/////////////////////////////////////////////////////////////////////////////////

			//////////////////////////new work
			
			//import borough polygon
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
//////////////////////////////for INPUTPOI file/////////////////////////////////////////////////////////////////////////////////

			tempLong = 0;
			GridNoAtStartLat = geoJsonArray[0][0][2];
			newPOICSV = new String [1][heightPOI];

			BufferedReader br2 = new BufferedReader(var2);
			lineRead = br2.readLine(); //this is headings line so ignore it should be line 0
			firstGeo = new double[] {Math.round((geoJsonArray[0][0][0])*1000000000000d)/1000000000000d, Math.round((geoJsonArray[0][0][1])*1000000000000d)/1000000000000d};

			for(int b=0;b<heightPOI-1;b++){//search the height of input POI
				int LongNoFixed=0;
				int findCount=0;
				find=true;
				flag1 = false;
				boolean flag = false;

				while(find){
					for(int j=0;j<(heightGeoJson/14);j++){//search the height of GEOJSON blocks
						if(findCount==0){
							if((j == longditudeGridWidth)&!flag){
								geoLong = geoJsonRightSideLatVals; //first right hand value
								find = liesWithinLong(inputPOI[0][b], geoLong, GridNo, firstGeo[0]);
								flag=true;
								//(and then j-1)??
							}else{
							geoLong = geoJsonArray[0][j][0];
							GridNo = geoJsonArray[0][j][2];
							find = liesWithinLong(inputPOI[0][b], geoLong, GridNo, firstGeo[0]);
							}
							if(outOfBoundsLong(inputPOI[0][b], geoJsonArray[0][j][0], GridNo)){
								GridPosFound=false;
								find=false;
								break;
							}
						}
						else{
							if((GridNo>=((heightGeoJson/14)-longditudeGridWidth) & GridNo<=(heightGeoJson/14)) & (LongNoFixed + (j-LongNoFixed)*longditudeGridWidth)>((heightGeoJson/14)-1)& !flag1){
								//in this section, need to compare to bottom row values
								geoLat = geoJsonBottomLatVals[LongNoFixed];
								GridNo = geoJsonArray[0][(LongNoFixed + (j-LongNoFixed-1)*longditudeGridWidth)][2];
								flag1 = true;
								find = liesWithinLat(inputPOI[1][b], geoLat, GridNo, firstGeo[1]);
								//(and then j-1)??
							}
							else if((LongNoFixed + (j-LongNoFixed)*longditudeGridWidth)>(heightGeoJson/14)){
								find=false;
								break;
							}
							else{
								geoLat = geoJsonArray[0][LongNoFixed + ((j-LongNoFixed)*longditudeGridWidth)][1]; //to match with lattitude, need to do fixed increments on length
								GridNo = geoJsonArray[0][LongNoFixed + ((j-LongNoFixed)*longditudeGridWidth)][2];
								find = liesWithinLat(inputPOI[1][b], geoLat, GridNo, firstGeo[1]);
								if(outOfBoundsLat(inputPOI[1][b], geoJsonArray[0][j][1], GridNo, GridNoAtStartLat)){
									GridPosFound=false;
									find=false;
									break;
								}
							}
						}
						if(find==false){
							GridPosFound=false;
						}
						else if(find==true){
							findCount=findCount+1;
							if (findCount==2){ //means has fou	nd long and lat
								findCount=0;
								GridPosFound=true;
								find=false;//allow it to exit the while loop
								if(LongNoFixed==j-1){
									LongNoFixed=j-1;
								}else{
									LongNoFixed = LongNoFixed + ((j-LongNoFixed-1)*longditudeGridWidth);
								}break;
							}
							else{
								j=j-1;
								LongNoFixed=j; //need for when jump out loop //dont need LongNoFixed because longditude skips means i will have the same longditude value
								j=j-1;
								GridNoAtStartLat = geoJsonArray[0][LongNoFixed][2];
								//to allow the increment of j so it will jump on same level
							}
						}
					}
					//read next line
					lineRead = br2.readLine();
					if(GridPosFound){
						newPOICSV[0][b] = lineRead.concat("," + Integer.toString((int)geoJsonArray[0][LongNoFixed][2]));
					}else {
						newPOICSV[0][b] = lineRead;
					}

				}
			}

			br2.close();
			System.out.println("Done");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		File file4 = new File(InputPOIFileName +"_GridAssociation.csv");
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(file4));		
			file4.createNewFile();

			StringBuilder sb = new StringBuilder();
			bw.write(firstLinePOI.concat(",GridNo"));
			bw.newLine();
			
			for(int j=0;j<(newPOICSV[0].length)-1;j++){
				bw.write(newPOICSV[0][j]);
				bw.newLine();
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


	public static boolean liesWithinLong(double inputPOI, double geoLong, double GridNo, double firstGeo){
		boolean found=false;

		if((inputPOI< geoLong) & GridNo==1){ //if it is instantly out of bounds, its not found
			found = false;
		}
		else if(inputPOI<geoLong & GridNo!=1){
			//use previous value as corner value and move onto lattitude 
			found = true;
		}
		else if (inputPOI>=geoLong & firstGeo==geoLong & GridNo!=1){ //what is exit condition of this loop? 
			//it is restarting again... 
			found = false;
		}
		else{
			//carry on looking by moving onto next loop
			//		found = false;
		}
		return found;
	}

	public static boolean liesWithinLat(double inputPOI, double geoLat, double GridNo, double firstGeo){
		boolean found=false;

		if((inputPOI> geoLat) & GridNo==1){ //if it is instantly out of bounds, its not found
			found = false;
		}
		else if(inputPOI>geoLat & GridNo!=1){
			//use previous value as corner value and move onto lattitude 
			found = true;
		}
		else if (inputPOI<=geoLat & firstGeo==geoLat & GridNo!=1){ //what is exit condition of this loop? 
			//it is restarting again... 
			found = false;
		}
		else{
			//carry on looking by moving onto next loop
			//		found = false;
		}
		return found;
	}

	public static boolean outOfBoundsLong(double inputPOI, double geoLong, double GridNo){ //need a top out of bounds too
		//pass through the j variable into another
		boolean outOfBounds1=false;
		if((inputPOI< geoLong) & (GridNo==1)){ //if it is instantly out of bounds, its not found
			outOfBounds1 = true;
		}
		else{ 
			outOfBounds1 = false;
		}
		return outOfBounds1;
	}

	public static boolean outOfBoundsLat(double inputPOI, double geoLat, double GridNo, double GridNoAtStartLat){ //need a top out of bounds too
		//pass through the j variable into another
		boolean outOfBounds1=false;
		if((inputPOI> geoLat) & (GridNo==GridNoAtStartLat)){ //if it is instantly out of bounds, its not found
			outOfBounds1 = true;
		}
		else{ 
			outOfBounds1 = false;
		}
		return outOfBounds1;
	}

}
