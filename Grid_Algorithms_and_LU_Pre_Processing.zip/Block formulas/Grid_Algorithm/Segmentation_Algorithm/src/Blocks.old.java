import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.*;
import java.util.Scanner;

public class Blocks {

	public static void main (String[] args){
		int R = 6371, roundedUpWidth, roundedUpHeight; //these are in Km
		double maxLat = 0, minLat = 0, maxLong = 0, minLong = 0, bearing12, bearing13, deltaLong, widthA, widthB, heightA, heightB, newLat, newLong, newLat2, newLong2; //may need 4 of these. but only ever somehing or 0;
		double[] point1 = new double [2], point2 = new double [2], point3 = new double [2], point4 = new double [2];
		double [] [] lattitudeArray, longditudeArray;
		String cityName;


		//0 is lat,,, 1 is long,,,


		Scanner input = new Scanner(System.in);

		System.out.println("This is a program to create a grid based system from given maximum and minimum co-ordinates of a given area");
		System.out.println("For this program to work, it requires the maxmimum lattitude, minimum latitude, maximum longditude, minimum longditude");
		System.out.println("Press any key to continue...");
		
		System.out.println("Please enter the name of the City:");
		cityName = input.nextLine().replace(" ", "_");
		
		System.out.println("Please enter the Maximum Lattitude");
		maxLat = input.nextDouble();

		System.out.println("Please enter the Minimum Lattitude");
		minLat = input.nextDouble();

		System.out.println("Please enter the Maximum Longditude");
		maxLong = input.nextDouble();

		System.out.println("Please enter the Minimum Longditude");
		minLong = input.nextDouble();


		point1[0] = maxLat; 
		point1[1] = minLong;

		point2[0] = maxLat; 
		point2[1] = maxLong;

		point3[0] = minLat; 
		point3[1] = minLong;

		point4[0] = minLat; 
		point4[1] = maxLong;

		//for point 1-2

		widthA = length(point1, point2, R);
		widthB = length(point3, point4, R);
		heightA = length(point1, point3, R);
		heightB = length(point2, point4, R);

		roundedUpWidth = (int) Math.ceil(Math.max(widthA, widthB)); //need to ensure ceil returns correct rounded result
		roundedUpHeight = (int) Math.ceil(Math.max(heightA, heightB));

		//if not even, then make even
		roundedUpWidth=evenChecker(roundedUpWidth);
		roundedUpHeight=evenChecker(roundedUpHeight);

		//array is in format - array[rows][columns] or... --array[y][x]
		lattitudeArray = new double [roundedUpWidth][roundedUpHeight]; //define new size for array for using two different arrays
		longditudeArray = new double [roundedUpWidth][roundedUpHeight];


		//bearing //1 to 2
		bearing12 = bearing(point1, point2); //should be equal to 0 

		//	bearing12 = bearing(point1[0], point1[1], point2[0], point2[1]);
		//these are for new co-ordinates that are 1-2
		newLat = NewLat(point1[0], bearing12, 1, R);
		newLong = NewLong(point1, bearing12, 1, newLat, R);
		lattitudeArray [roundedUpWidth-1][0] = Math.toDegrees(newLat);
		longditudeArray [roundedUpWidth-1][0] = Math.toDegrees(newLong);


		//1 to 3
		bearing13 = bearing(point1, point3); //should be equal to 180
		//these are for new co-ordinates that are 1-3
		newLat2 = NewLat(point1[0], bearing13, roundedUpHeight, R);
		newLong2 = NewLong(point1, bearing13, roundedUpHeight, newLat2, R);
		lattitudeArray [0][roundedUpHeight-1] = Math.toDegrees(newLat2);
		longditudeArray [0][roundedUpHeight-1] = Math.toDegrees(newLong2);

		
		//initialize
		lattitudeArray[0][0] =  point1[0];
		longditudeArray[0][0] = point1[1];

		//does width calcs first
		double []tempPoint = new double [2];
		//initialize top row
		for (int i=1; i<roundedUpWidth;i++){

			tempPoint[0] = lattitudeArray[i-1][0];
			tempPoint[1] = longditudeArray[i-1][0];

			newLat = NewLat(lattitudeArray[i-1][0], bearing12, 1, R);
			newLong = NewLong(tempPoint, bearing12, 1, newLat, R);
			lattitudeArray [i][0] = Math.toDegrees(newLat);
			longditudeArray [i][0] = Math.toDegrees(newLong);
		}


		for (int i=0; i<roundedUpWidth;i++){
			for (int j=1; j<roundedUpHeight;j++){
				tempPoint[0] = lattitudeArray[i][j-1];
				tempPoint[1] = longditudeArray[i][j-1];
				lattitudeArray[i][j] = Math.toDegrees(NewLat(lattitudeArray[i][j-1], bearing13, 1, R));
				longditudeArray[i][j] = Math.toDegrees(NewLong(tempPoint, bearing13, 1, lattitudeArray[i][j], R));
			}
		}	

		System.out.println("Rounded Up Width = " + roundedUpWidth);
		System.out.println("Rounded Up Height = " + roundedUpHeight);
		System.out.println("");

		System.out.println("Bearing 1 to 2 is = " + bearing12);
		System.out.println("Bearing 1 to 3 is = " + bearing13);
		System.out.println("");

		System.out.println("This is from 1 to 2 co-ordinates");
		System.out.println("Lattitude = " + lattitudeArray [roundedUpWidth-1][0]);
		System.out.println("Longditude = " + longditudeArray [roundedUpWidth-1][0]);
		System.out.println("");

		System.out.println("This is from 1 to 3 co-ordinates");
		System.out.println("Lattitude = " + lattitudeArray [0][roundedUpHeight-1]);
		System.out.println("Longditude = " + longditudeArray [0][roundedUpHeight-1]);
		System.out.println("");
		
		System.out.println("Done! File '" + cityName + "_Grid_Coordinates.geojson' saved in project source directory.");

		//print to geojson

		File file = new File(cityName + "_Grid_Coordinates.geojson");
		try {
			file.createNewFile();

			BufferedWriter br = new BufferedWriter(new FileWriter(file));
			StringBuilder sb = new StringBuilder();
			//longditude first lattitude second

			int x = 0;
			sb.append("{ \"type\": \"FeatureCollection\",");
			br.write(sb.toString());
			br.newLine();

			sb.setLength(0);
			sb.append("  \"features\": [");
			br.write(sb.toString());
			br.newLine();
			br.newLine();

			for(int j = 0;j<roundedUpHeight-1;j++){
				for(int i = 0; i<roundedUpWidth-1;i++){
					sb.setLength(0);
					sb.append("    { \"type\": \"Feature\",");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("      \"geometry\": {");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("        \"type\": \"Polygon\",");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("        \"coordinates\": [");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("          [ [" + longditudeArray[i][j] + "," + lattitudeArray[i][j] + "],");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("            [" + longditudeArray[i+1][j] + "," + lattitudeArray[i+1][j] + "],");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("            [" + longditudeArray[i+1][j+1] + "," + lattitudeArray[i+1][j+1] + "],");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("            [" + longditudeArray[i][j+1] + "," + lattitudeArray[i][j+1] + "] ]");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("        ]");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("      },");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					sb.append("      \"properties\": {");
					br.write(sb.toString());
					br.newLine();

					x=x+1;
					sb.setLength(0);
					sb.append("        \"prop0\": \" " + x + "\"}");
					br.write(sb.toString());
					br.newLine();

					sb.setLength(0);
					if((j==roundedUpHeight-2) & (i==roundedUpWidth-2)) {
						sb.append("    }");	
					}
					else{
					sb.append("    },");
					}
					br.write(sb.toString());
					br.newLine();
					br.newLine();
				}
			}

			sb.setLength(0);
			sb.append("  ]");
			br.write(sb.toString());
			br.newLine();

			sb.setLength(0);
			sb.append("}");
			br.write(sb.toString());
			br.newLine();

			br.close();


		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}




	public static int evenChecker (int input){
		// if odd
		if (input % 2 != 0) {
			input = input +1;
		} 
		return input;
	}


	public static double NewLat(double point1Lat, double bearing, double roundedLength, double R) {//dont really need the whole co-ordinate, just point1[0]
		double newLat = 0;

		newLat = Math.asin((Math.sin(Math.toRadians(point1Lat))*Math.cos((double)roundedLength/R)) + (Math.cos(Math.toRadians(point1Lat))*Math.sin((double)roundedLength/R)*Math.cos(bearing)));

		return newLat;


	}


	public static double NewLong(double pointx[], double bearing, double roundedLength, double newLat, double R) {//dont really need the whole co-ordinate, just point1[0]
		double newLong = 0;
		double temp = (double)roundedLength/R;

		newLong = ((Math.toRadians(pointx[1])) + (Math.atan2(Math.sin(bearing)*Math.sin(temp)*Math.cos(Math.toRadians(pointx[0])), 
				Math.cos(temp)-Math.sin(Math.toRadians(pointx[0]))*Math.sin(newLat))));

		newLong = ((newLong+3*Math.PI) % (2*Math.PI)) - Math.PI;
		return newLong;
	}


	public static double bearing(double[] pointx, double[] pointy){
		double y = Math.sin(Math.toRadians(pointy[1] - pointx[1])) * Math.cos(Math.toRadians(pointy[0]));
		double x = Math.cos(Math.toRadians(pointx[0]))*Math.sin(Math.toRadians(pointy[0])) -
				Math.sin(Math.toRadians(pointx[0]))*Math.cos(Math.toRadians(pointy[0]))*Math.cos(Math.toRadians(pointy[1] - pointx[1]));

		return (Math.atan2(y, x));
	}

	public static double length(double[] pointx, double[] pointy, int R){
		double deltaLong;
		double Length;
		double sigma;

		deltaLong = ((Math.toRadians(pointx[1])) - (Math.toRadians(pointy[1])));
		sigma = Math.acos(((Math.sin(Math.toRadians(pointx[0])))*(Math.sin(Math.toRadians(pointy[0]))))+
				((Math.cos(Math.toRadians(pointx[0])))*(Math.cos(Math.toRadians(pointy[0])))*(Math.cos(deltaLong))));

		Length = R*sigma;

		return Length;
	}
}
