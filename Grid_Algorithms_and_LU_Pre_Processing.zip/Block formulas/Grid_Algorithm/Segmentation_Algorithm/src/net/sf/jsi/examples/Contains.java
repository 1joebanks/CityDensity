package net.sf.jsi.examples;

import gnu.trove.TIntProcedure;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.awt.Polygon;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.Object;

import org.locationtech.spatial4j.*;
import org.locationtech.spatial4j.context.SpatialContext;
import org.locationtech.spatial4j.context.SpatialContextFactory;
import org.locationtech.spatial4j.exception.InvalidShapeException;
import org.locationtech.spatial4j.io.GeoJSONReader;
import org.locationtech.spatial4j.shape.Shape;
import org.locationtech.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.noggit.*;

import com.infomatiq.jsi.Rectangle;
import com.infomatiq.jsi.SpatialIndex;
import com.infomatiq.jsi.rtree.RTree;
import org.json.simple.*;

public class Contains {
  private static final Logger log = LoggerFactory.getLogger(Contains.class);
private static final String String = null;
  
  public static void main(String[] args) {
    new Contains().run();
  }
 
  private void run() {
    // Create and initialize an rtree
    SpatialIndex si = new RTree();
    si.init(null);
    
    // We have some points or rectangles in some other data structure.
    // The rtree can handle millions of these.
    Rectangle[] rects = new Rectangle[] {
        new Rectangle(0, 0, 0, 0),
        new Rectangle(0, 1, 0, 1),
        new Rectangle(1, 0, 1, 0),
        new Rectangle(1, 1, 1, 1),
    };
    
    double[] LatPoints, LongPoints;
    int NoOfPoints;
    
   // Polygon Borough = new Polygon();
    
   // Borough = new Polygon(xpoints, ypoints, npoints) problem with polygon is that it cannot have double values
    
   Path2D borough = new Path2D.Double();
 //  borough.moveTo(NoOfPoints, NoOfPoints);//could be LineTo
   double[][]BoroughArray = null;

 //  BoroughArray.moveTo(valoresX[0], valoresY[0]);
//for(int i = 0; i < BoroughArray.length; ++i) {
//	borough.lineTo(BoroughArray[i][0], BoroughArray[i][1]);
//}
//borough.closePath();
   Scanner input = new Scanner(System.in);
   JsonSimpleExample JsonSimpleExample = new JsonSimpleExample();
//   JsonSimpleExample.

// boolean geo;
String CityGridCoordsGeoFileName;
   System.out.println("Please enter the name of the GEOJSON grid co-ordinates file (excluding extension) : ");
//	CityGridCoordsGeoFileName = input.nextLine();
	
	
  // protected Shape readPolygon(org.noggit.JSONParser parser);
    File file1 = new File ("camden.geo.json");
   FileReader var1;

	
//			var1 = new FileReader(file1);
		

//   BufferedReader br1 = new BufferedReader(var1);
   
	Point2D SquarePoint = new Point2D.Double(1.2, 2.3);
	
   if(borough.contains(SquarePoint)){
	   //do stuff
   }
    // Add our data to the rtree. Every time we add a rectangle we give it
    // an ID. This ID is what is returned by querying the rtree. In this 
    // example we use the array index as the ID.
    for (int i = 0; i < rects.length; i++) {
      si.add(rects[i], i);
    }

    // Now see which of these points is contained by some
    // other rectangle. The rtree returns the results of a query
    // by calling the execute() method on a TIntProcedure.
    // In this example we want to save the results of the query 
    // into a list, so that's what the execute() method does.
    class SaveToListProcedure implements TIntProcedure {
      private List<Integer> ids = new ArrayList<Integer>();

      public boolean execute(int id) {
        ids.add(id);
        return true;
      }; 
      
      private List<Integer> getIds() {
        return ids;
      }
    };
    
    SaveToListProcedure myProc = new SaveToListProcedure();
    si.contains(new Rectangle(1f, 0f, 1f, 0f), myProc); // which points from the previous defined rectangle does this new square contain? 
    
    //the question i need to figure out is what needs to go into the R tree? initial thought is the grid squares?
    List<Integer> ids = myProc.getIds();
    
    for (Integer id : ids) {
      System.out.println(rects[id].toString() + " was contained      cxvfd      ");
    }
    
    // Actually that was a really long winded (and inefficient) way of 
    // printing out the rectangles. Would be better to use an anonymous
    // class to just do the printing inside the execute method. That is
    // what the NearestN class does.
  
}
	    }
  