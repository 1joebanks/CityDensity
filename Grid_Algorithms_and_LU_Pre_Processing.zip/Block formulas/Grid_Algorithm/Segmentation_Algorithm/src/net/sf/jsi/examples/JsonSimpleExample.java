package net.sf.jsi.examples;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JsonSimpleExample {
	public static void main(String[] args) {

		JSONParser parser = new JSONParser();
		Scanner input = new Scanner(System.in);
		double[][][] GridCoordinates=null;
		double[][] boroughPolygon=null;
		String PolygonBoroughFN;

		System.out.println("Please enter the name of the geo.json Polygon file (excluding extensions) : ");
		PolygonBoroughFN = input.nextLine();
		System.out.println("Please enter the just the file name of the GEOJSON grid co-ordinates file (excluding extensions) : ");
		String GridCoordinatesFN = input.nextLine();

		boroughPolygon = PolygonGeoJSONtoArray(parser, PolygonBoroughFN);
		GridCoordinates = GridCoordinatesGeoJSONtoArray(parser, GridCoordinatesFN);
		System.out.println("done");
	}

	public static double[][] PolygonGeoJSONtoArray(JSONParser parser, String PolygonBoroughFN ){
		double[][] boroughPolygon = null;
		Object obj = null;
		try {
			obj = parser.parse(new FileReader(System.getProperty("user.dir") + "\\" + PolygonBoroughFN));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject jsonObject = (JSONObject) obj;
		JSONObject geometry = (JSONObject) jsonObject.get("geometry");
		JSONArray coordinates = (JSONArray) geometry.get("coordinates");
		Iterator<String> iterator = coordinates.iterator();
		int i=0;
		while (iterator.hasNext()) {

			JSONArray CoordinatesSurroundingArray = (JSONArray) coordinates.get(0);
			Iterator<String> SurroundingArrayIterator = CoordinatesSurroundingArray.iterator();
			boroughPolygon = new double[2][CoordinatesSurroundingArray.size()];
			while(SurroundingArrayIterator.hasNext()){
				JSONArray CoordinatesPointArray = (JSONArray) CoordinatesSurroundingArray.get(i);
				Iterator<String> PointArrayIterator = CoordinatesPointArray.iterator();
				while(PointArrayIterator.hasNext()){
					boroughPolygon[0][i] = (double) CoordinatesPointArray.get(0);
					PointArrayIterator.next();
					boroughPolygon[1][i] = (double) CoordinatesPointArray.get(1);
					PointArrayIterator.next();
				}
				i=i+1;
				SurroundingArrayIterator.next();
			}
			iterator.next();
		}
		return boroughPolygon;
	}

	public static double[][][] GridCoordinatesGeoJSONtoArray(JSONParser parser, String GridCoordinatesFN ){
		double[][][] boroughPolygon = null;

		Object obj = null;
		try {
			obj = parser.parse(new FileReader(System.getProperty("user.dir") + "\\" + GridCoordinatesFN + ".geojson"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject jsonObject = (JSONObject) obj;

		JSONArray features = (JSONArray) jsonObject.get("features");
		Iterator<String> featuresiterator = features.iterator();
		int i=0;
		int j=0;
		boroughPolygon = new double[features.size()][2][4];
		while (featuresiterator.hasNext()) {//while there are more features to look at
			//now at the first feature, there is an object called geometry
			JSONObject featureI = (JSONObject) features.get(i); //take the ith feature and make it an object
			JSONObject geometry = (JSONObject) featureI.get("geometry");
			JSONArray CoordinatesSurroundingArray = (JSONArray) geometry.get("coordinates");

			j=0;
			JSONArray CoordinatesSurroundingArray1in = (JSONArray) CoordinatesSurroundingArray.get(0);
			Iterator<String> CoordinatesSurroundingArray1inIterator = CoordinatesSurroundingArray1in.iterator();
			while(CoordinatesSurroundingArray1inIterator.hasNext()){
				JSONArray CoordinatesPointArray = (JSONArray) CoordinatesSurroundingArray1in.get(j);
				Iterator<String> PointArrayIterator = CoordinatesPointArray.iterator();
				while(PointArrayIterator.hasNext()){
					boroughPolygon[i][0][j] = (double) CoordinatesPointArray.get(0);
					PointArrayIterator.next();
					boroughPolygon[i][1][j] = (double) CoordinatesPointArray.get(1);
					PointArrayIterator.next();
				}
				j=j+1;
				CoordinatesSurroundingArray1inIterator.next();
			}
			featuresiterator.next();
			i=i+1;
		}
		return boroughPolygon;
	}
}