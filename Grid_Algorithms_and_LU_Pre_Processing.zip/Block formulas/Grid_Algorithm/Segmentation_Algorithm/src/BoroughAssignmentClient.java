import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import net.sf.jsi.examples.JsonSimpleExample;

import org.json.simple.parser.JSONParser;

public class BoroughAssignmentClient {

	public static void main (String[] args){

		int NumberOfFilesInDir = new File(System.getProperty("user.dir")).list().length;
		String[] FilesInDir = new File(System.getProperty("user.dir")).list();
		System.out.println("There are " + NumberOfFilesInDir + " Files in project root directory");
		int NoOfGeojsonFiles=0;
		List<String> allGeoJsonFiles = new ArrayList<String>(); 
		Scanner input = new Scanner(System.in);

		JSONParser parser = new JSONParser();
		double[][][] GridCoordinates=null;
		double[][] boroughPolygon=null;
		String GridCoordinatesFN;
		System.out.println("Please enter the just the City Name of the GEOJSON grid co-ordinates file (excluding extensions) : ");
		GridCoordinatesFN = input.nextLine();

		GridCoordinates = JsonSimpleExample.GridCoordinatesGeoJSONtoArray(parser, GridCoordinatesFN);

		//finds the number of geojson files in the directory
		for(int i = 0;i<NumberOfFilesInDir;i++){ //makes sure it does not include the CityGridCoordsGeoFileName in the list as that is GEOJSON too, we only want the borough GEOJSON
			if(FilesInDir[i].contains(".geo.json")){//may need to remove the .csv
				allGeoJsonFiles.add(FilesInDir[i]);
				NoOfGeojsonFiles = NoOfGeojsonFiles + 1;
			}
		}

		Iterator<String> itr = allGeoJsonFiles.iterator();
		int n = 0;
		try {
			String FinalBoroughs = allGeoJsonFiles.get(n).substring(0, allGeoJsonFiles.get(n).indexOf("."));
			File file4 = new File("BoroughGridCellDistribution" +".csv");
			BufferedWriter bw = new BufferedWriter(new FileWriter(file4));		
			file4.createNewFile();
			bw.write("Borough,GridNo");
			bw.newLine();

			while(itr.hasNext()){//while there are remaining GeoJson files in the directory
				//uses one borough at a time
				boroughPolygon = JsonSimpleExample.PolygonGeoJSONtoArray(parser, allGeoJsonFiles.get(n));

				//create polygon of the borough
				Path2D borough = new Path2D.Double();
				borough.moveTo(boroughPolygon[0][0], boroughPolygon[1][0]);//could be LineTo
				for (int i=1; i<boroughPolygon[0].length;i++){ //number of points
					borough.lineTo(boroughPolygon[0][i], boroughPolygon[1][i]);//could be LineTo
				}
				borough.closePath();

				//for every square in the grid, check if it is within the borough polygon
				boolean[][] included = new boolean[GridCoordinates.length][GridCoordinates[0][0].length];
				for(int i=0;i<GridCoordinates.length;i++){ //grid Number
					for(int k=0;k<GridCoordinates[0][0].length;k++){ //point number
						Point2D SquarePoint = new Point2D.Double(GridCoordinates[i][0][k], GridCoordinates[i][1][k]);
						included[i][k] = borough.contains(SquarePoint);
					}
				}
				FinalBoroughs = allGeoJsonFiles.get(n).substring(0, allGeoJsonFiles.get(n).indexOf("."));

				int count = 0;
				int noOfGrids=0;
				FinalBoroughs = FinalBoroughs.concat(",\"");
				for(int i =0; i<included.length;i++){
					for(int k = 0; k<included[0].length;k++){
						if(included[i][k]){
							count=count+1;
						}
					}
					if(count>=1 && noOfGrids==0){//i!=0 to avoid first commaa
						FinalBoroughs = FinalBoroughs.concat(""+ (i-1));
						noOfGrids= noOfGrids+1;
					}
					else if(count>=1 && noOfGrids!=0){ 
						FinalBoroughs = FinalBoroughs.concat(", " + (i-1));
						noOfGrids= noOfGrids+1;
					}
					count=0;
				}
				FinalBoroughs = FinalBoroughs.concat("\"");
				System.out.println(FinalBoroughs);

				bw.write(FinalBoroughs);
				bw.newLine();
				n=n+1;
				itr.next();
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("File is stored in '" + System.getProperty("user.dir") + "\\BoroughGridCellDistribution'");
	}

}
