import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Scanner;

import org.json.simple.parser.JSONParser;

import net.sf.jsi.examples.JsonSimpleExample;


public class Grid_Assignment {
	public static void main (String[] args){
		String[][] newPOICSV = null;
		String firstLinePOI = null;
		double inputPOI[][] ;
		double[][][]geoJsonArray;
		int longitudeGridWidth = 0;
		int GeoJasonj =0;
		double[] geoJsonBottomLatVals, firstGeo;
		double GridNoAtStartLat;
		double geoLong, geoLat = 0, GridNo = 0;
		double geoJsonRightSideLatVal = 0;
		boolean find = false, flag1 = false, GridPosFound=false;
		String GridCoordinatesFN, InputPOIFileName;
		Scanner input = new Scanner(System.in);

		System.out.println("This program, given coordinates assigns the corresonding grid numbera grid number generatred from assiciated blocks program.");
		System.out.println("The program needs to have use of two files, the GEOJSON grid coordinates file, and a file of your "
				+ "choice in CSV format, with the first two columns assigned longitude and latitude respecitvely,"
				+ "and any other columns after that will remain in the updated file. In the updated file, there will be an additional column named"
				+ " gridNo with each entry having a number associated to it if it is within the given boundaries of the geojson grid square.");
		System.out.println("Please first ensure the two files are saved in this Java file's root directory");

		System.out.println("Please enter the name of the GEOJSON grid co-ordinates (without extention):");
		GridCoordinatesFN = input.nextLine();

		System.out.println("Please enter the name of the input points of intereset CSV file (without extention):");
		InputPOIFileName = input.nextLine();

		String[] cols;
		File file = new File (InputPOIFileName + ".csv");
		FileReader var;

		File file2 = new File (InputPOIFileName + ".csv"); //uses a second for buffer recreation
		FileReader var2;

		try {
			var = new FileReader(file);
			var2 = new FileReader(file2);

			BufferedReader br = new BufferedReader(var);
			String lineRead = null;
			try {

				int heightPOI = 0;
				LineNumberReader reader = null;//chagned mind, just get first 2 columns
				reader = new LineNumberReader(new FileReader(file));

				while ((reader.readLine()) != null);
				heightPOI= reader.getLineNumber();

				lineRead = br.readLine();
				firstLinePOI = lineRead;
				cols = lineRead.split(",");	

				inputPOI = new double [2][heightPOI];

				for(int j=0; j<heightPOI-1;j++){
					lineRead = br.readLine();
					for (int i = 0; i<2;i++){
						lineRead.startsWith("\"");
						cols = lineRead.split(",");	
						inputPOI[i][j] = Double.parseDouble(cols[i]);
					}
				}
				br.close();


				//////////////////////////////for GeoJson file/////////////////////////////////////////////////////////////////////////////////


				JSONParser parser = new JSONParser();
				geoJsonArray = JsonSimpleExample.GridCoordinatesGeoJSONtoArray(parser, GridCoordinatesFN);

				//get the width of the grid
				double tempLong = Math.round((geoJsonArray[0][0][0])*1000000000000d)/1000000000000d;	
				while(longitudeGridWidth==0){ 
					GeoJasonj++;
					if( Math.round((geoJsonArray[GeoJasonj][0][0])*1000000000000d)/1000000000000d == tempLong & longitudeGridWidth==0 ){	//width		
						longitudeGridWidth = GeoJasonj;	
					}
				}
				geoJsonRightSideLatVal = geoJsonArray[longitudeGridWidth-1][0][1];

				geoJsonBottomLatVals = new double[longitudeGridWidth];
				for(int b = 0; b<longitudeGridWidth;b++){ 
					geoJsonBottomLatVals[b]=geoJsonArray[geoJsonArray.length-(longitudeGridWidth-b)][1][2];
				}

				//////////////////////////////for GeoJson file end/////////////////////////////////////////////////////////////////////////////////

				//////////////////////////////for INPUTPOI file/////////////////////////////////////////////////////////////////////////////////

				GridNoAtStartLat = 1;
				newPOICSV = new String [1][heightPOI];

				BufferedReader br2 = new BufferedReader(var2);
				lineRead = br2.readLine(); //this is headings line so ignore it should be line 0
				firstGeo = new double[] {Math.round((geoJsonArray[0][0][0])*1000000000000d)/1000000000000d, Math.round((geoJsonArray[0][1][0])*1000000000000d)/1000000000000d};

				//NOTE: Alternative is using R-trees approach.
				for(int b=0;b<heightPOI-1;b++){//search the height of input POI
					int LongNoFixed=0;
					int findCount=0;
					find=true;
					flag1 = false;
					boolean flag = false;

					while(find){
						for(int j=0;j<(geoJsonArray.length);j++){//search the height of GEOJSON blocks
							if(findCount==0){
								if((j == longitudeGridWidth)&!flag){
									geoLong = geoJsonRightSideLatVal; //first right hand value
									find = liesWithinLong(inputPOI[0][b], geoLong, GridNo, firstGeo[0]);
									flag=true;
								}else{
									geoLong = geoJsonArray[j][0][0];
									GridNo = j+1;
									find = liesWithinLong(inputPOI[0][b], geoLong, GridNo, firstGeo[0]);
								}
								if(outOfBoundsLong(inputPOI[0][b], geoJsonArray[j][0][0], GridNo)){
									GridPosFound=false;
									find=false;
									break;
								}
							}
							else{
								if((GridNo>=((geoJsonArray.length)-longitudeGridWidth) & GridNo<=(geoJsonArray.length)) & (LongNoFixed + (j-LongNoFixed)*longitudeGridWidth)>=(geoJsonArray.length)& !flag1){
									//in this section, need to compare to bottom row values
									geoLat = geoJsonBottomLatVals[LongNoFixed];
									GridNo = (LongNoFixed + (j-LongNoFixed-1)*longitudeGridWidth)+1;
									flag1 = true;
									find = liesWithinLat(inputPOI[1][b], geoLat, GridNo, firstGeo[1]);
								}
								else if((LongNoFixed + (j-LongNoFixed)*longitudeGridWidth)>(geoJsonArray.length)){
									find=false;
									break;
								}
								else{
									geoLat = geoJsonArray[LongNoFixed + ((j-LongNoFixed)*longitudeGridWidth)][1][0]; //to match with latitude, need to do fixed increments on length
									GridNo = LongNoFixed + ((j-LongNoFixed)*longitudeGridWidth)+1;
									find = liesWithinLat(inputPOI[1][b], geoLat, GridNo, firstGeo[1]);
									if(outOfBoundsLat(inputPOI[1][b], geoJsonArray[j][1][0], GridNo, GridNoAtStartLat)){
										GridPosFound=false;
										find=false;
										break;
									}
								}
							}
							if(find==false){
								GridPosFound=false;
							}
							else if(find==true){
								findCount=findCount+1;
								if (findCount==2){ //means has found long and lat
									findCount=0;
									GridPosFound=true;
									find=false;//allow it to exit the while loop
									if(LongNoFixed==j-1){
										LongNoFixed=j-1;
									}else{
										LongNoFixed = LongNoFixed + ((j-LongNoFixed-1)*longitudeGridWidth);
									}break;
								}
								else{
									j=j-1;
									LongNoFixed=j; //need for when jump out loop //dont need LongNoFixed because longitude skips means i will have the same longitude value
									j=j-1;
									GridNoAtStartLat = LongNoFixed+1;
									//to allow the increment of j so it will jump on same level
								}
							}
						}
						//read next line
						lineRead = br2.readLine();
						if(GridPosFound){
							newPOICSV[0][b] = lineRead.concat("," + Integer.toString((int)LongNoFixed));
						}else {
							newPOICSV[0][b] = lineRead;
						}
					}
				}
				br2.close();
				System.out.println("Done");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		//create new gird associated csv file
		File file4 = new File(InputPOIFileName +"_GridAssociation.csv");
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(file4));		
			file4.createNewFile();
			bw.write(firstLinePOI.concat(",GridNo"));
			bw.newLine();
			for(int j=0;j<(newPOICSV[0].length)-1;j++){
				bw.write(newPOICSV[0][j]);
				bw.newLine();
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public static boolean liesWithinLong(double inputPOI, double geoLong, double GridNo, double firstGeo){
		boolean found=false;

		if((inputPOI< geoLong) & GridNo==1){ //if it is instantly out of bounds, its not found
			found = false;
		}
		else if(inputPOI<geoLong & GridNo!=1){
			//use previous value as corner value and move onto latitude 
			found = true;
		}
		else if (inputPOI>=geoLong & firstGeo==geoLong & GridNo!=1){ //what is exit condition of this loop? 
			//it is restarting again... 
			found = false;
		}
		else{
			//carry on looking by moving onto next loop
			//		found = false;
		}
		return found;
	}

	public static boolean liesWithinLat(double inputPOI, double geoLat, double GridNo, double firstGeo){
		boolean found=false;

		if((inputPOI> geoLat) & GridNo==1){ //if it is instantly out of bounds, its not found
			found = false;
		}
		else if(inputPOI>geoLat & GridNo!=1){
			//use previous value as corner value and move onto latitude 
			found = true;
		}
		else if (inputPOI<=geoLat & firstGeo==geoLat & GridNo!=1){ //what is exit condition of this loop? 
			//it is restarting again... 
			found = false;
		}
		else{
			//carry on looking by moving onto next loop
			//		found = false;
		}
		return found;
	}

	public static boolean outOfBoundsLong(double inputPOI, double geoLong, double GridNo){ //need a top out of bounds too
		//pass through the j variable into another
		boolean outOfBounds1=false;
		if((inputPOI< geoLong) & (GridNo==1)){ //if it is instantly out of bounds, its not found
			outOfBounds1 = true;
		}
		else{ 
			outOfBounds1 = false;
		}
		return outOfBounds1;
	}

	public static boolean outOfBoundsLat(double inputPOI, double geoLat, double GridNo, double GridNoAtStartLat){ //need a top out of bounds too
		//pass through the j variable into another
		boolean outOfBounds1=false;
		if((inputPOI> geoLat) & (GridNo==GridNoAtStartLat)){ //if it is instantly out of bounds, its not found
			outOfBounds1 = true;
		}
		else{ 
			outOfBounds1 = false;
		}
		return outOfBounds1;
	}

}
